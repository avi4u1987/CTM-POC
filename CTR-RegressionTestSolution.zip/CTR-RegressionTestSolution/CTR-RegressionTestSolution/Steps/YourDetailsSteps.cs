﻿namespace CTR_RegressionTestSolution.Steps
{
    using CTR_RegressionTestSolution.Pages;

    using NUnit.Framework;

    using TechTalk.SpecFlow;
   [Binding]
   public class YourDetailsSteps
    {
        private readonly YourDetailsPage yourDetailsPage;

        public YourDetailsSteps()
        {
            yourDetailsPage = new YourDetailsPage(StepContext.Driver);
        }

        [Then(@"Your details section should be displayed")]
        public void ThenYourDetailsSectionShouldBeDisplayed()
        {
            Assert.IsTrue(this.yourDetailsPage.IsIntroDisplayed(), "Your details page intro is not displayed");
        }

        [When(@"Provide your detail")]
        public void WhenProvideYourDetail()
        {
            ProvideYourDetails();
        }

       private void ProvideYourDetails()
       {
           this.yourDetailsPage.SelectTariffType();
           this.yourDetailsPage.SelectPaymentType();
           this.yourDetailsPage.TypeEmail("test@test.com");
           this.yourDetailsPage.OptForMarketingEmails();
           this.yourDetailsPage.OptForTermAndCondition();
           this.yourDetailsPage.GotoPrice();
       }

    }
}
