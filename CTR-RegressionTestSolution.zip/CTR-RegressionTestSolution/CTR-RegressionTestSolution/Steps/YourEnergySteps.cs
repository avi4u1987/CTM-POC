﻿
namespace CTR_RegressionTestSolution.Spets
{
    using System.Threading;

    using CTR_RegressionTestSolution.Pages;

    using NUnit.Framework;

    using TechTalk.SpecFlow;
    [Binding]
    public class YourEnergySteps
    {
        private readonly YourEnergyPage yourEnergyPage;

        public YourEnergySteps()
        {
            yourEnergyPage = new YourEnergyPage(StepContext.Driver);
        }

        [Then(@"Your energy section should be displayed")]
        public void ThenYourEnergySectionShouldBeDisplayed()
        {
           Assert.IsTrue(this.yourEnergyPage.IsIntroDisplayed(), "Your energy page intro is not displayed");
        }

        [Given(@"Provide your energy details")]
        [When(@"Provide your energy details")]
        public void WhenProvideYourEnergyDetails()
        {
            this.ProvideElectricityDetails();
            this.ProvideGasDetails();
        }

        private void ProvideElectricityDetails()

        {
            this.yourEnergyPage.ProvideElectricityUsage("200");
            this.yourEnergyPage.GoToYourEnergySection();
            Thread.Sleep(3000);
        }

        private void ProvideGasDetails()
        {
            this.yourEnergyPage.ProvideGasUsage("100");
            this.yourEnergyPage.GoToYourEnergySection();
            Thread.Sleep(3000);
        }
    }
}
