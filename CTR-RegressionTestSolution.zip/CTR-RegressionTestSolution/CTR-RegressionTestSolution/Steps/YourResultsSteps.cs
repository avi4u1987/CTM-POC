﻿
namespace CTR_RegressionTestSolution.Steps
{
    using CTR_RegressionTestSolution.Pages;

    using NUnit.Framework;

    using TechTalk.SpecFlow;

   [Binding]
   public class YourResultsSteps
    {
        private readonly YourResultPage yourResultPage;

        public YourResultsSteps()
        {
            yourResultPage = new YourResultPage(StepContext.Driver);
        }

        [Then(@"Your result section should be displayed")]
        public void ThenYourResultsSectionShouldBeDisplayed()
        {
            Assert.IsTrue(this.yourResultPage.IsAvailableTariffMessageDisplayed(), "Your results page section is not displayed");
        }
    }
}
