﻿namespace CTR_RegressionTestSolution.Spets
{
    using CTR_RegressionTestSolution.Pages;

    using TechTalk.SpecFlow;

    [Binding]
   public class YourSupplierSteps
    {
        private readonly YourSupplierPage yourSupplierPage;

        public YourSupplierSteps()
        {
            yourSupplierPage = new YourSupplierPage(StepContext.Driver);
        }

        [Given(@"Go to compare gas and electricity website")]
        public void GivenGoToCompareGasAndElectricityWebsite()
        {
           this.yourSupplierPage.NavigateToHomePage();
        }

        [Given(@"Add post code '(.*)'")]
        public void GivenAddPostCode(string postCode)
        {
            this.yourSupplierPage.ProvidePostCode(postCode);
        }
        
        [When(@"I go to next page")]
        public void WhenIGoToNextPage()
        {
            this.yourSupplierPage.ClickOnNextButton();
        }

        [Given(@"Provide your supplier details")]
        public void GivenProvideYourSupplierDetails()
        {
            GivenAddPostCode("Se7 7NN");
            WhenIGoToNextPage();
        }

       }
}
