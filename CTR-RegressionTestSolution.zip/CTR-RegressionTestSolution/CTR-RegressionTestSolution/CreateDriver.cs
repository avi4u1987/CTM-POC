﻿namespace CTR_RegressionTestSolution
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Chrome;
    using OpenQA.Selenium.Firefox;
    using OpenQA.Selenium.IE;

    public static class CreateDriver
    {
        private static IWebDriver driver;

        public static IWebDriver SetupDriver(string selectedBrowser)
        {
            switch (selectedBrowser.ToLower())
            {
                case "firefox":
                    driver = new FirefoxDriver();
                    return driver;

                case "ie":
                    driver = new InternetExplorerDriver("drivers");
                    return driver;

                case "chrome":
                    driver = new ChromeDriver();
                    return driver;

                default:
                    System.Console.WriteLine("Invalid browser specified");
                    return driver;
            }
        }
    }
}
