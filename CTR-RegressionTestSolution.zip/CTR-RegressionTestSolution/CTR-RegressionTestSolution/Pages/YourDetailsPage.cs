﻿namespace CTR_RegressionTestSolution.Pages
{
    using System.Threading;

    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.PageObjects;

    public class YourDetailsPage : BasePage
    {
        [FindsBy(How = How.CssSelector, Using = ".intro")]
        private IWebElement intro;

        [FindsBy(How = How.CssSelector, Using = ".icon.fixed-rate-1")]
        private IWebElement tariffType;

        [FindsBy(How = How.CssSelector, Using = ".icon.annual-1")]
        private IWebElement paymentType;

        [FindsBy(How = How.CssSelector, Using = "#Email")]
        private IWebElement emailAddressTextBox;

        [FindsBy(How = How.XPath, Using = ".//*[@id='marketingT']/div/div[2]/label/span[2]")]
        private IWebElement marketingEmail;

        [FindsBy(How = How.XPath, Using = ".//*[@id='terms-label']/span[2]")]
        private IWebElement TermAndCondition;

        [FindsBy(How = How.CssSelector, Using = "#email-submit")]
        private IWebElement GoToPriceButton;

        public YourDetailsPage(IWebDriver driver)
            : base(driver)
        {
        }

        public bool IsIntroDisplayed()
        {
            return this.intro.Displayed;
        }

        public void SelectTariffType()
        {
            this.tariffType.Click();
        }

        public void SelectPaymentType()
        {
            this.paymentType.Click();
        }

        public void TypeEmail(string email)
        {
            this.emailAddressTextBox.SendKeys(email);
        }

        public void OptForMarketingEmails()
        {
            this.marketingEmail.Click();
        }

        public void OptForTermAndCondition()
        {
            this.TermAndCondition.Click();
        }

        public void GotoPrice()
        {
            this.GoToPriceButton.Click();
          Thread.Sleep(10000);
        }
    }
}
