﻿namespace CTR_RegressionTestSolution.Pages
{
    using System.Threading;

    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.PageObjects;

    public class YourSupplierPage : BasePage
    {
        [FindsBy(How = How.CssSelector, Using = "#your-postcode")]
        private IWebElement yourPostCodeTestBox;

        [FindsBy(How = How.CssSelector, Using = "#find-postcode")]
        private IWebElement findPostCodeButton;

        [FindsBy(How = How.CssSelector, Using = "#goto-your-supplier-details")]
        private IWebElement nextButton;

       public YourSupplierPage(IWebDriver driver) : base(driver)
       {
       }

        public void ProvidePostCode(string postCode)
        {
            this.yourPostCodeTestBox.SendKeys(postCode);
            this.findPostCodeButton.Click();
            Thread.Sleep(3000);
        }

        public void ClickOnNextButton()
        {
            this.nextButton.Click();
            Thread.Sleep(3000);
        }
    }
}
