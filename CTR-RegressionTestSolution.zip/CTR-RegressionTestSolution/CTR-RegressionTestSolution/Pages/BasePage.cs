﻿
namespace CTR_RegressionTestSolution.Pages
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.PageObjects;

   public class BasePage 
    {
        private IWebDriver Driver;

        public BasePage(IWebDriver driver)
        {
            this.Driver = driver;
            PageFactory.InitElements(driver, this);
        }

        public void NavigateToHomePage()
        {
            this.Driver.Navigate().GoToUrl(StepContext.BaseUrl);
        }
    }
}
