﻿
namespace CTR_RegressionTestSolution.Pages
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.PageObjects;

    public class YourEnergyPage : BasePage
    {
       [FindsBy(How = How.CssSelector, Using = ".intro")]
       private IWebElement intro;

        [FindsBy(How = How.CssSelector, Using = "#electricity-usage")]
        private IWebElement electrictyUsage;

        [FindsBy(How = How.CssSelector, Using = "#gas-usage")]
        private IWebElement gasUsage;

        [FindsBy(How = How.CssSelector, Using = "#goto-your-energy")]
        private IWebElement nextButton;

        public YourEnergyPage(IWebDriver driver) : base(driver)
        {
            
        }

        public bool IsIntroDisplayed()
        {
            return this.intro.Displayed;
        }

        public void ProvideElectricityUsage(string electrictyUsage)
        {
            this.electrictyUsage.SendKeys(electrictyUsage);
        }

        public void ProvideGasUsage(string gasUsage)
        {
            this.gasUsage.SendKeys(gasUsage);
        }
        public void GoToYourEnergySection()
        {
            this.nextButton.Click();
        }
    }
}
