﻿
namespace CTR_RegressionTestSolution.Pages
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.PageObjects;

    public class YourResultPage : BasePage
    {
       [FindsBy(How = How.CssSelector, Using = ".results-title>p")]
       private IWebElement availableTariffMessage;

     public YourResultPage(IWebDriver driver) : base(driver)
        { }

        public bool IsAvailableTariffMessageDisplayed()
        {
            return this.availableTariffMessage.Displayed;
        }
    }
}
