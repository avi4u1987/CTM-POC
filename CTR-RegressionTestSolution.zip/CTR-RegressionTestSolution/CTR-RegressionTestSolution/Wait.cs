﻿namespace CTR_RegressionTestSolution
{
    using System;

    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;

    public class Wait
    {
        private const int ExplicitWaitInSeconds = 30;

        private readonly IWebDriver driver;

        private readonly JavaScriptExecutorWrapper javaScriptExecutorRetryWrapper;

        public Wait(IWebDriver driver)
        {
            this.driver = driver;
            this.javaScriptExecutorRetryWrapper = new JavaScriptExecutorWrapper(driver);
        }

        public void Until(Func<IWebDriver, bool> waitCondition, int timeoutInSeconds)
        {
            var wait = new WebDriverWait(this.driver, TimeSpan.FromSeconds(timeoutInSeconds));
            wait.PollingInterval = TimeSpan.FromMilliseconds(50); // AJAX calls can be quick, so it's better we poll more frequently (default is 500ms).
            wait.Until(waitCondition);
        }

        public void Until(Func<IWebDriver, bool> waitCondition)
        {
            this.Until(waitCondition, ExplicitWaitInSeconds);
        }

        public void UntilAjaxCallIsDone(int timeoutInSeconds)
        {
            this.Until(d =>
            {
                var isAjaxCallDone = bool.Parse(this.javaScriptExecutorRetryWrapper.ExecuteScript("var $ = require('jquery'); return $.active == 0").ToString().ToLower());

                if (!isAjaxCallDone)
                {
                    Console.WriteLine("AJAX call in progress");
                }

                // return true when finished AJAX call
                return isAjaxCallDone;
            }, timeoutInSeconds);
        }
    }
}
