﻿namespace CTR_RegressionTestSolution
{
    using OpenQA.Selenium;
    using TechTalk.SpecFlow;
    using System.Configuration;

    [Binding]
    public static class StepContext
    {
        public static IWebDriver Driver { get; private set; }

        public static string BaseUrl { get; private set; }

        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            var selectedBrowser = ConfigurationManager.AppSettings["browser"];
            BaseUrl = ConfigurationManager.AppSettings["url"];
            Driver = CreateDriver.SetupDriver(selectedBrowser);
        }

        [AfterTestRun]
        public static void AfterTestRun()
        {
            Driver.Quit();
        }
    }
 }
