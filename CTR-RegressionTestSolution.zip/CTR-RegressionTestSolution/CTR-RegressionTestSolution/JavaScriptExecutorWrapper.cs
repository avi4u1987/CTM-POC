﻿namespace CTR_RegressionTestSolution
{
       using System;
    using System.Threading;

    using OpenQA.Selenium;

    public class JavaScriptExecutorWrapper : IJavaScriptExecutor
    {
        private readonly IJavaScriptExecutor javaScriptExecutor;

        public JavaScriptExecutorWrapper(IWebDriver driver)
        {
            this.javaScriptExecutor = (IJavaScriptExecutor)driver;
        }

        public object ExecuteScript(string script, params object[] args)
        {
            return this.CatchAndRetry(() => this.javaScriptExecutor.ExecuteScript(script, args));
        }

        public object ExecuteAsyncScript(string script, params object[] args)
        {
            throw new NotImplementedException();
        }

        private object CatchAndRetry(Func<object> executeFunc, int retryCount = 1)
        {
            try
            {
                return executeFunc();
            }
            catch (Exception)
            {
                if (retryCount <= 4)
                {
                    Thread.Sleep(1000 * retryCount);
                    return this.CatchAndRetry(executeFunc, ++retryCount);
                }

                throw;
            }
        }
    }
}
